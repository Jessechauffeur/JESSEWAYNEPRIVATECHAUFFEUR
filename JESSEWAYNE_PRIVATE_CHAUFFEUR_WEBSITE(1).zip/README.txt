JESSEWAYNE PRIVATE CHAUFFEUR — GitHub Pages website package

Files:
- index.html: single-page responsive website
- assets/jessewayne-logo.png: supplied black-and-gold logo
- assets/chauffeur-owner.png: supplied owner portrait
- assets/white-chauffeur-vehicle.jpg: supplied white vehicle photo
- assets/taxi-kcx-469b.jpg: supplied red KCX 469B taxi photo
- robots.txt and sitemap.xml: basic crawl/indexing support

Important:
1. The booking form opens WhatsApp with the customer's enquiry. It does not store bookings in a database and does not confirm a booking automatically.
2. Check the email address and Instagram link in index.html before launch.
3. Facebook, TikTok and direct Google Business Profile links can be added when their exact URLs are available.
4. The canonical URL assumes the existing GitHub Pages address: https://jessechauffeur.github.io/Jesse-private-chauffeur-/
5. After uploading these files to the root of that GitHub repository, commit changes and ensure GitHub Pages is enabled. Then test the live website and submit the URL in Google Search Console.
6. Do not upload passwords or private customer data to the repository.
